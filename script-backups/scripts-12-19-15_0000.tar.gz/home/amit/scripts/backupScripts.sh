#!/bin/sh

THEDATE=`date +%m-%d-%y_%H%M`

tar -czPf /home/amit/backups/script-backups/scripts-${THEDATE}.tar.gz --exclude-vcs /home/amit/scripts

find /home/amit/backups/script-backups/scripts* -mtime +1 -exec rm {} \;
