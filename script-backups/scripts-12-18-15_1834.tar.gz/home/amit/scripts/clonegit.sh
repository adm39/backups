#!/bin/sh

rm -rf /home/amit/backups/
git clone https://github.com/adm39/backups
                                          
