
# "grimey savages that's what we are" - Team Savage
This is the entire contents of webpage in /var/www/frontend.
Front End for teamsavage.com
